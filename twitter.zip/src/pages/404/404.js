import React from 'react';

const P404 = () => {
    return (
        <div>
            <h1>404</h1>
            <p>صفحه مورد نظر یافت نشد</p>
        </div>
    )
}

export default P404;